SETUP (XAMPP)
1. Start Apache and MySQL in the XAMPP Control Panel.
2. Open http://localhost/phpmyadmin > SQL tab > paste/run database.sql
3. Copy the folder "hospital-appointment" into C:\xampp\htdocs\
4. Open http://localhost/hospital-appointment/

Files: database.sql, config.php, index.php (doctor directory + department filter),
book.php (form + available slots + token generation), token.php (token slip / lookup), style.css
